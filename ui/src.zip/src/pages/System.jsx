// ui/src/pages/System.jsx
// LPR_GATEBOX UI
// Версия: v0.3.2
// Обновлено: 2026-02-08
//
// Что сделано:
// - NEW: блок Telegram в "Система" (token/enabled/paired/test)
// - KEEP: UI управления updater (status/check/start/report/log)
// - KEEP: карточка "Ресурсы" (CPU/RAM/DISK + docker stats) из /api/v1/system/metrics

import React, { useEffect, useMemo, useState } from "react";
import { apiGet, apiPost, apiDownload, getSettings, putSettings } from "../api"; // <-- api.js в src

function fmtMB(x) {
  if (x == null || Number.isNaN(x)) return "—";
  if (x > 1024) return `${(x / 1024).toFixed(1)} GB`;
  return `${Math.round(x)} MB`;
}

function fmtPct(x) {
  if (x == null || Number.isNaN(x)) return "—";
  return `${Number(x).toFixed(1)}%`;
}

function fmtInt(x) {
  if (x == null || Number.isNaN(x)) return "—";
  return `${Math.round(x)}`;
}

function pickContainer(containers, name) {
  if (!Array.isArray(containers)) return null;
  return containers.find((c) => c?.name === name) || null;
}

function KeyVal({ k, v, mono }) {
  return (
    <div className="kv">
      <div className="kvK">{k}</div>
      <div className={`kvV ${mono ? "mono" : ""}`}>{v}</div>
    </div>
  );
}

export default function SystemPage() {
  const [health, setHealth] = useState(null);
  const [metrics, setMetrics] = useState(null);

  const [updStatus, setUpdStatus] = useState(null);
  const [updLog, setUpdLog] = useState([]);

  const [err, setErr] = useState("");

  // Telegram (config/settings)
  const [tgSettings, setTgSettings] = useState(null);
  const [tgDirty, setTgDirty] = useState(false);
  const [tgInfo, setTgInfo] = useState("");
  const [tgErr, setTgErr] = useState("");
  const [tgBusy, setTgBusy] = useState(false);

  async function loadHealth() {
    const h = await apiGet("/api/v1/health");
    setHealth(h);
  }

  async function loadMetrics() {
    const m = await apiGet("/api/v1/system/metrics");
    setMetrics(m);
  }

  async function loadUpdaterStatus() {
    const s = await apiGet("/api/v1/update/status");
    setUpdStatus(s);
  }

  async function loadUpdaterLog() {
    const l = await apiGet("/api/v1/update/log");
    setUpdLog(Array.isArray(l?.log) ? l.log : []);
  }

  async function loadTelegramSettings() {
    const r = await getSettings();
    setTgSettings(r?.settings || {});
  }

  function patchTelegram(path, value) {
    setTgSettings((prev) => {
      const next = JSON.parse(JSON.stringify(prev || {}));
      const parts = String(path || "").split(".");
      let cur = next;
      for (let i = 0; i < parts.length - 1; i++) {
        const k = parts[i];
        if (cur[k] == null || typeof cur[k] !== "object") cur[k] = {};
        cur = cur[k];
      }
      cur[parts[parts.length - 1]] = value;
      return next;
    });
    setTgDirty(true);
  }

  async function saveTelegramSettings() {
    try {
      setTgErr("");
      setTgInfo("");
      setTgBusy(true);
      const r = await putSettings(tgSettings || {});
      setTgSettings(r?.settings || tgSettings);
      setTgDirty(false);
      setTgInfo("Сохранено. Если менял token — нажми «Обновить сейчас» (перезапустит gatebox).");
    } catch (e) {
      setTgErr(String(e?.message || e));
    } finally {
      setTgBusy(false);
    }
  }

  async function telegramTest() {
    try {
      setTgErr("");
      setTgInfo("");
      setTgBusy(true);
      const withPhoto = !!(tgSettings?.telegram?.send_photo ?? true);
      const r = await apiPost("/api/v1/telegram/test", {
        text: "✅ GateBox: тест Telegram (из UI / Система)",
        with_photo: withPhoto,
      });
      if (r?.ok) setTgInfo("Отправлено ✅ Проверь Telegram-чат.");
      else setTgErr(r?.error || "Не удалось отправить тест");
    } catch (e) {
      setTgErr(String(e?.message || e));
    } finally {
      setTgBusy(false);
    }
  }

  async function loadAll() {
    try {
      setErr("");
      await Promise.all([loadHealth(), loadMetrics(), loadUpdaterStatus(), loadTelegramSettings()]);
      await loadUpdaterLog();
    } catch (e) {
      setErr(String(e?.message || e));
    }
  }

  useEffect(() => {
    loadAll();
    const t = setInterval(() => {
      loadAll();
    }, 5000);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const host = metrics?.host || null;
  const containers = metrics?.containers || null;

  const cGatebox = useMemo(() => pickContainer(containers, "gatebox"), [containers]);
  const cWorker = useMemo(() => pickContainer(containers, "rtsp_worker"), [containers]);
  const cUpdater = useMemo(() => pickContainer(containers, "updater"), [containers]);

  const diskRoot = host?.disk_root || null;
  const diskProject = host?.disk_project || null;
  const diskConfig = host?.disk_config || null;

  async function onCheck() {
    try {
      setErr("");
      await apiPost("/api/v1/update/check", {});
      await loadUpdaterStatus();
      await loadUpdaterLog();
    } catch (e) {
      setErr(String(e?.message || e));
    }
  }

  async function onStart() {
    try {
      setErr("");
      await apiPost("/api/v1/update/start", {});
      await loadUpdaterStatus();
      await loadUpdaterLog();
    } catch (e) {
      setErr(String(e?.message || e));
    }
  }

  async function onReport() {
    try {
      setErr("");
      await apiDownload("/api/v1/update/report", "gatebox_report.zip");
    } catch (e) {
      setErr(String(e?.message || e));
    }
  }

  async function onRefreshLog() {
    try {
      setErr("");
      await loadUpdaterLog();
    } catch (e) {
      setErr(String(e?.message || e));
    }
  }

  const updRunning = !!updStatus?.running;
  const updStep = updStatus?.step || "—";
  const updLast = updStatus?.last_result || "—";

  return (
    <div className="col">
      {err ? (
        <div className="alert alert-error">
          <div style={{ fontWeight: 800, marginBottom: 6 }}>Ошибка</div>
          <div className="mono">{err}</div>
        </div>
      ) : null}

      <div className="grid2">
        {/* HEALTH */}
        <div className="card">
          <div className="cardHead">
            <div className="cardTitle">Состояние</div>
            <div className="row">
              <span className={`badge ${health?.ok ? "badge-green" : "badge-red"}`}>
                {health?.ok ? "OK" : "BAD"}
              </span>
            </div>
          </div>
          <div className="cardBody">
            <div className="kvGrid">
              <KeyVal k="version" v={health?.version || "—"} mono />
              <KeyVal k="git" v={health?.git || "—"} mono />
              <KeyVal k="build_time" v={health?.build_time || "—"} mono />
              <KeyVal k="uptime" v={health?.uptime_sec != null ? `${health.uptime_sec}s` : "—"} mono />
              <KeyVal k="model" v={health?.model || "—"} mono />
              <KeyVal k="settings" v={health?.settings_path || "—"} mono />
            </div>

            <div className="lastBlock">
              <div className="row" style={{ justifyContent: "space-between" }}>
                <div>
                  <div className="muted">MQTT</div>
                  <div className="mono">
                    {health?.mqtt?.enabled ? "enabled" : "disabled"}{" "}
                    {health?.mqtt?.host ? `@ ${health.mqtt.host}:${health.mqtt.port}` : ""}
                  </div>
                </div>
                <div className="badge badge-blue">
                  topic: <span className="mono">{health?.mqtt?.topic || "—"}</span>
                </div>
              </div>

              <div style={{ marginTop: 10 }}>
                <div className="muted">Последний номер</div>
                <div className="plateBig mono">{health?.last_plate || "—"}</div>
              </div>
            </div>
          </div>
        </div>

        {/* UPDATER */}
        <div className="card">
          <div className="cardHead">
            <div className="cardTitle">Обновления</div>
            <div className="row">
              <button className="btn btn-ghost" type="button" onClick={loadAll}>
                Обновить
              </button>
            </div>
          </div>
          <div className="cardBody">
            <div className="row" style={{ justifyContent: "space-between" }}>
              <span className={`badge ${updRunning ? "badge-yellow" : "badge-gray"}`}>
                {updRunning ? "RUNNING" : "IDLE"}
              </span>
              <span className="badge badge-gray">
                step: <span className="mono">{updStep}</span>
              </span>
              <span
                className={`badge ${
                  updLast === "ok" ? "badge-green" : updLast === "error" ? "badge-red" : "badge-gray"
                }`}
              >
                last: <span className="mono">{updLast}</span>
              </span>
            </div>

            <div className="row" style={{ marginTop: 12, gap: 10 }}>
              <button className="btn btn-primary" type="button" onClick={onCheck} disabled={updRunning}>
                Проверить
              </button>
              <button className="btn btn-danger" type="button" onClick={onStart} disabled={updRunning}>
                Обновить сейчас
              </button>
              <button className="btn btn-ghost" type="button" onClick={onReport}>
                Скачать отчёт
              </button>
            </div>

            <div className="lastBlock" style={{ marginTop: 12 }}>
              <div className="row" style={{ justifyContent: "space-between" }}>
                <div className="cardTitle" style={{ fontSize: 14 }}>
                  Логи updater (tail)
                </div>
                <div className="row">
                  <button className="btn btn-ghost" type="button" onClick={onRefreshLog}>
                    Обновить логи
                  </button>
                </div>
              </div>

              <div
                className="mono"
                style={{
                  marginTop: 10,
                  whiteSpace: "pre-wrap",
                  maxHeight: 220,
                  overflow: "auto",
                  background: "rgba(0,0,0,.22)",
                  border: "1px solid rgba(255,255,255,.06)",
                  borderRadius: 12,
                  padding: 10,
                }}
              >
                {updLog && updLog.length ? updLog.slice(-120).join("\n") : "—"}
              </div>
            </div>

            <div className="hint">
              “Обновить сейчас” сделает docker-compose pull + up -d. Во время обновления UI может кратко моргнуть — это
              нормально.
            </div>
          </div>
        </div>
      </div>

      {/* TELEGRAM */}
      <div className="card">
        <div className="cardHead">
          <div className="cardTitle">Telegram</div>
          <div className="row">
            <span className={`badge ${tgSettings?.telegram?.enabled ? "badge-green" : "badge-gray"}`}>
              {tgSettings?.telegram?.enabled ? "enabled" : "disabled"}
            </span>
            <span className={`badge ${tgSettings?.telegram?.chat_id ? "badge-green" : "badge-red"}`}>
              {tgSettings?.telegram?.chat_id ? "paired" : "not paired"}
            </span>
          </div>
        </div>

        <div className="cardBody">
          <div className="kvGrid">
            <KeyVal k="bot_token" v={tgSettings?.telegram?.bot_token ? "••••••••••••" : "—"} mono />
            <KeyVal k="chat_id" v={tgSettings?.telegram?.chat_id || "—"} mono />
            <KeyVal k="send_photo" v={String(!!(tgSettings?.telegram?.send_photo ?? true))} mono />
          </div>

          <div className="lastBlock" style={{ marginTop: 12 }}>
            <div className="row" style={{ gap: 10, flexWrap: "wrap" }}>
              <label className="row" style={{ gap: 8 }}>
                <input
                  type="checkbox"
                  checked={!!tgSettings?.telegram?.enabled}
                  onChange={(e) => patchTelegram("telegram.enabled", e.target.checked)}
                />
                <span>Уведомления Telegram</span>
              </label>

              <label className="row" style={{ gap: 8 }}>
                <input
                  type="checkbox"
                  checked={!!(tgSettings?.telegram?.send_photo ?? true)}
                  onChange={(e) => patchTelegram("telegram.send_photo", e.target.checked)}
                />
                <span>Присылать фото</span>
              </label>
            </div>

            <div style={{ marginTop: 12 }}>
              <div className="muted" style={{ marginBottom: 6 }}>
                Token бота (клиент может создать своего бота через BotFather)
              </div>
              <input
                className="input"
                type="password"
                value={tgSettings?.telegram?.bot_token || ""}
                placeholder="123456:ABCDEF..."
                onChange={(e) => patchTelegram("telegram.bot_token", e.target.value)}
              />
              <div className="hint" style={{ marginTop: 8 }}>
                1) Вставь token → Сохранить. 2) Открой бота и нажми <span className="mono">/start</span>. 3) Нажми
                “Отправить тест”.
              </div>
            </div>

            {tgErr ? (
              <div className="alert alert-error" style={{ marginTop: 12 }}>
                <div style={{ fontWeight: 800, marginBottom: 6 }}>Ошибка</div>
                <div className="mono">{tgErr}</div>
              </div>
            ) : null}
            {tgInfo ? (
              <div className="alert" style={{ marginTop: 12 }}>
                <div style={{ fontWeight: 800, marginBottom: 6 }}>OK</div>
                <div>{tgInfo}</div>
              </div>
            ) : null}

            <div className="row" style={{ marginTop: 12, gap: 10, flexWrap: "wrap" }}>
              <button className="btn btn-primary" type="button" onClick={saveTelegramSettings} disabled={!tgDirty || tgBusy}>
                Сохранить
              </button>
              <button className="btn btn-ghost" type="button" onClick={() => patchTelegram("telegram.chat_id", null)} disabled={tgBusy}>
                Сбросить привязку
              </button>
              <button className="btn btn-primary" type="button" onClick={telegramTest} disabled={tgBusy}>
                Отправить тест
              </button>
              <button className="btn btn-ghost" type="button" onClick={loadTelegramSettings} disabled={tgBusy}>
                Обновить
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* RESOURCES */}
      <div className="card">
        <div className="cardHead">
          <div className="cardTitle">Ресурсы</div>
          <div className="row">
            <span className="badge badge-gray">host</span>
            <span className="badge badge-yellow">rtsp_worker</span>
            <span className="badge badge-blue">gatebox</span>
            <span className="badge badge-gray">updater</span>
          </div>
        </div>

        <div className="cardBody">
          {!metrics ? (
            <div className="muted">Загрузка…</div>
          ) : (
            <div className="grid2">
              <div className="card" style={{ background: "rgba(255,255,255,.02)" }}>
                <div className="cardHead">
                  <div className="cardTitle">Хост</div>
                  <div className="badge badge-gray">load1: {host?.load1 != null ? host.load1 : "—"}</div>
                </div>
                <div className="cardBody">
                  <div className="kvGrid">
                    <KeyVal k="cpu" v={fmtPct(host?.cpu_pct)} mono />
                    <KeyVal k="ram used" v={fmtMB(host?.mem_used_mb)} mono />
                    <KeyVal k="ram total" v={fmtMB(host?.mem_total_mb)} mono />
                    <KeyVal k="ram avail" v={fmtMB(host?.mem_avail_mb)} mono />
                  </div>

                  <div className="lastBlock">
                    <div className="muted">Disk /</div>
                    <div className="mono">
                      {diskRoot?.used_mb != null && diskRoot?.total_mb != null
                        ? `${fmtInt(diskRoot.used_mb)} MB / ${fmtInt(diskRoot.total_mb)} MB`
                        : "—"}
                    </div>

                    <div style={{ marginTop: 10 }} className="muted">
                      Disk /project
                    </div>
                    <div className="mono">
                      {diskProject?.used_mb != null && diskProject?.total_mb != null
                        ? `${fmtInt(diskProject.used_mb)} MB / ${fmtInt(diskProject.total_mb)} MB`
                        : "—"}
                    </div>

                    <div style={{ marginTop: 10 }} className="muted">
                      Disk /config
                    </div>
                    <div className="mono">
                      {diskConfig?.used_mb != null && diskConfig?.total_mb != null
                        ? `${fmtInt(diskConfig.used_mb)} MB / ${fmtInt(diskConfig.total_mb)} MB`
                        : "—"}
                    </div>
                  </div>

                  <div className="footer">
                    <span className="badge badge-gray">
                      ts: <span className="mono">{host?.ts || "—"}</span>
                    </span>
                  </div>
                </div>
              </div>

              <div className="card" style={{ background: "rgba(255,255,255,.02)" }}>
                <div className="cardHead">
                  <div className="cardTitle">Контейнеры</div>
                  <div className="muted">docker stats</div>
                </div>
                <div className="cardBody">
                  <div className="table">
                    <div className="tr th">
                      <div>name</div>
                      <div>cpu</div>
                      <div>mem</div>
                    </div>

                    {Array.isArray(containers) && containers.length ? (
                      containers.map((c, idx) => (
                        <div className="tr" key={idx}>
                          <div className="mono">{c?.name || "—"}</div>
                          <div className="mono">{c?.cpu_pct || "—"}</div>
                          <div className="mono">{c?.raw_mem || "—"}</div>
                        </div>
                      ))
                    ) : (
                      <div className="muted">Нет данных</div>
                    )}
                  </div>

                  <div className="hint" style={{ marginTop: 10 }}>
                    Если rtsp_worker стабильно &gt;100% CPU — это нормально (YOLO + декод), но можно снижать DET_FPS/READ_FPS
                    или уменьшать imgsz.
                  </div>

                  <div className="footer">
                    <span className="badge badge-gray">
                      gatebox cpu: <span className="mono">{cGatebox?.cpu_pct || "—"}</span>
                    </span>
                    <span className="badge badge-gray">
                      worker cpu: <span className="mono">{cWorker?.cpu_pct || "—"}</span>
                    </span>
                    <span className="badge badge-gray">
                      updater cpu: <span className="mono">{cUpdater?.cpu_pct || "—"}</span>
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}